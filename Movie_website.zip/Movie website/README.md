#MOVIE WEBSITE CREATION#
This project for movie website creation has been developed for creating a simple website.
The website will contain some animation **movie posters** and their respective **trailers**.

##Set up##

To set up this particular project in a local environment, the user must ensure certain software requirements
like,

* Python GUI (6.7.13)
* A system which supports python
* Web browser
* An Internet connection

The user must know the code basics of python.Basic concepts of implementation of classes and functions must be
known.

You can find some cool trailers of movies of any genere here in the link given.
[Trailers](www.youtube.com)

##Steps Involved##

*Step 1*: Create a class file which includes several attributes of what the class should contain.
 _for example_
```
class Movie():
    def __init__(self,movie_title,movie_storyline,poster_image,trailer_youtube):

 _for example_
```

*Step 2*: Create instance for the above attributes of the function inside the class file.
```
self.title = movie_title
self.storyline = movie_storyline
```

*Step 3*: In order to display the trailer in a webbroser, we need to import it form the
	  python library at the beginning of the class file.

 _for example_ 
```
 import webbrowser
```

*Step 4* : Intoduce a seperate function to open a webbrowser and display the trailer.

_for example_
```
def show_trailer(self):
        webbrowser.open(self.trailer_youtube_url
```
*Step 5*: Create another file which includes the code for the appearence of the website.

*Step 6*: Create a seperate file which includes the movie names that are to be included in the website.
	  this file must be have the instances related to the class and its attributes and it should acquire the properties of
	  that class.

_for example_

```
Emoji = cinema.Movie("Emoji Movie",
                     "A story of emojis",
                     "https://upload.wikimedia.org/wikipedia/en/6/63/The_Emoji_Movie_film_poster.jpg",
                     "https://www.youtube.com/watch?v=4yZERI42eRU&vl=en")
```
* here *cinema* denotes name of class file.
* *Movie* is the class name.
* The info specified inside the brraces will be related to the attributes of the function inside the class(__init__).
   * *Emoji movie* is the movie title.
   * *A story of emojis* is the story line.
   * [https://upload.wikimedia.org/wikipedia/en/6/63/The_Emoji_Movie_film_poster.jpg] is the poster_image url.
   * [https://www.youtube.com/watch?v=4yZERI42eRU&vl=en] is the youtube trailer url.

*Step 7* : list out the movie names and assign it to a variable.

_ for example_

```
movies = [Emoji,Frozen,boss_baby,angry_birds,smurfs]
```
*Step 8* : Invoke the file which was designed for the appearence of the website to display the movies in the website.

_ for example_

```
fresh_tomatoes.open_movies_page(movies)
```

*Step 9* : Finally, import the class file and the file which was created for appeatence of the website.

_for example_

```
import fresh_tomatoes
import cinema
```
here *fresh_tomatoes* is the file which includes the code for the appearence of the website.

*Step 10* : Save all the 3 files with different names seperately and with the _.py_ extension.

##Implementation##
  To implement the project and run it successfully, the user needs to ensure that their code is free from any
of the errors in code as well as other softwares that are used for the project.

* Note: run the file that contains appearance of the website to view the output of the project.*

##Testing##

The user can run the project by including 2 or 3 movie names and their posters in order to test the project.








 
