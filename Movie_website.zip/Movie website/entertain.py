"""
Module that uses the content of media.py to define Class Movie
"""


import fresh_tomatoes
import cinema

#These are multiple instances of the Class Movie
Emoji = cinema.Movie(
    "Emoji Movie", 
    "A story of emojis", 
    "https://upload.wikimedia.org/wikipedia/en/6/63/The_Emoji_Movie_film_poster.jpg",  # noqa  
    "https://www.youtube.com/watch?v=4yZERI42eRU&vl=en")


Frozen = cinema.Movie(
    "Frozen", 
    "A story about a fearless princess who takes an adventure in land of ice", 
    "https://vignette2.wikia.nocookie.net/frozen/images/5/58/Frozen-movie-poster.jpg/revision/latest?cb=20140115094640",  # noqa 
    "https://www.youtube.com/watch?v=TbQm5doF_Uc")


boss_baby = cinema.Movie(
    "bossbaby", 
    "A story about how a new baby's arrival impact a family", 
    "https://upload.wikimedia.org/wikipedia/en/0/0e/The_Boss_Baby_poster.jpg",  # noqa 
    "https://www.youtube.com/watch?v=O2Bsw3lrhvs")

angry_birds = cinema.Movie(
    "AngryBirds", 
    "animation story about birds",
    "https://upload.wikimedia.org/wikipedia/en/f/f9/The_Angry_Birds_Movie_poster.png",  # noqa  
    "https://www.youtube.com/watch?v=0qJzWrq7les")

smurfs = cinema.Movie(
    "The Smurfs", 
    "A story about little blue creatures", 
    "https://upload.wikimedia.org/wikipedia/en/1/19/The_Smurfs_2_poster.jpg",  # noqa  
    "https://www.youtube.com/watch?v=vu1qZCG6Yo8")

# A variable called movies is created,
# to store an array of movie list
movies = [Emoji, Frozen, boss_baby, angry_birds, smurfs]

# A function "open_movies_page is called,
# The movie list is passed to this function
# as inputs,which translates it into a webpage
# when we run the entertainment.py or fresh_tomatoes.py program
fresh_tomatoes.open_movies_page(movies)
